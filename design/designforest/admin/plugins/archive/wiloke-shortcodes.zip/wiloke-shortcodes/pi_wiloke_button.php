<?php 
$atts = shortcode_atts(
	array(
		'button_name' 	=> 'Button',
		'contextual'	=> 'btn-danger',
		'size'			=> 'btn-default',
		'link'			=> ''
	),
	$atts
);



if ( !empty($atts['link']) )
{
	$open 	= '<a href="'.esc_url($atts['link']).'"';
	$close 	= '</a>';
}else{
	$open   = '<button';
	$close  = '</button>';
}

$output .= $open .' class="btn h-btn btn-default '.esc_attr($atts['size']) . ' ' . esc_attr($atts['contextual']) . ' ">';
$output .= wp_unslash($atts['button_name']);
$output .= $close;

return $output;
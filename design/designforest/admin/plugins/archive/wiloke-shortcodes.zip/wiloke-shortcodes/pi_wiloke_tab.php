<?php
$atts = shortcode_atts(
	array(
		'title'		=> 'Tab Title',
		'content'	=> 'Tab Content'
	),
	$atts
);

$id = uniqid("tabs_");


$output .= '<li class="pi-title"><a href="#'.esc_attr($id).'">' . wp_unslash($atts['title']) . '</a></li>';

$output .=  '<div id="'.esc_attr($id).'" class="tab-content">';
	$output .= '<p>' . wp_unslash($atts['content']) . '</p>';
$output .= '</div>';

return $output;
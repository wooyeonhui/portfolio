<?php
$atts = shortcode_atts(
	array(
		'percent'		=>	50,
		'contextual'	=> 'success',
		'striped'		=> 'striped',
		'active'		=> 'active'
	),
	$atts
);

$contextual = 'progress-bar-' . $atts['contextual'];
$striped    = !empty($atts['striped']) ? 'progress-bar-striped' : '';

$output .= '<div class="progress">';
  $output .= '<div class="progress-bar '.esc_attr($contextual) . ' ' . esc_attr($atts['active']) . ' ' . esc_attr($striped) .'" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: '.$atts['percent'].'%">';
  $output .= '</div>';
$output .= '</div>';

return $output;
;(function($, window, document, undefined)
{
	"use strict";

	tinymce.PluginManager.add('pi_shortcodes', function( editor, url ) 
	{
		editor.addButton( 'pi_shortcodes', {
			text: 'Wiloke Shortcodes',
			icon: WILOKEASSETURL + 'images/shorcodes.png',
			type: 'menubutton',
			menu: 
			[
				{	
					text: 'Progress bar',
					onclick: function()
					{ 
						piDisplaySettings('progress');
					},
				},
				{	
					text: 'Button',
					onclick: function()
					{ 
						piDisplaySettings('button');
					},
				},
				{	
					text: 'Quote',
					onclick: function()
					{ 
						piDisplaySettings('quote');
					},
				},
				{	
					text: 'Alert',
					onclick: function()
					{ 
						piDisplaySettings('alert');
					},
				},
				{	
					text: 'Panel',
					onclick: function()
					{ 
						piDisplaySettings('panel');
					},
				},
				{	
					text: 'Tabs',
					onclick: function()
					{ 
						piDisplaySettings('tabs');
					},
				},
				{	
					text: 'Accordion',
					onclick: function()
					{ 
						piDisplaySettings('accordion');
					},
				},
				{	
					text: 'Contact Form 7',
					onclick: function()
					{ 
						piDisplaySettings('contactform7');
					},
				}
			]
		});
	});

	function piDisplaySettings(shortcode)
	{
		$(".pi-shortcode-settings").css({display:'none'}).removeClass("active");

		tb_show(shortcode.toUpperCase() + " Shortcode", "#TB_inline?height=500&amp;width=785&amp;inlineId=pi-wrap-shortcode");

		$("#pi-"+shortcode+"-sc").css({display:'block'}).addClass("active"); 

		var _getSettings = "";

		$("#pi-insert-shortcode").click(function()
		{
			var _children="", _children_name="";
			if ( shortcode == 'tabs' || shortcode == 'accordion' )
			{
				_children_name = shortcode == 'tabs' ? 'pi_tab' : 'pi_item';

				$("#pi-"+shortcode+"-sc .pi-item").each(function()
				{
					_children += '[' + _children_name +' ';

					$(this).find(".form-control").each(function()
					{
						_children +=  $(this).attr("name") + '="' + $(this).val() + '" ';
					})

					_children = _children.trim();

					_children += ']';
				})

				_getSettings = '[pi_wiloke_'+shortcode+']' + _children + '[/pi_wiloke_'+shortcode+']';
			}else if(shortcode == 'contactform7'){
					_getSettings = '[contact-form-7 id="'+$("#pi-get-contactform7").val()+'" title="'+$("#pi-get-contactform7").find("option:selected").data("title")+'"]';
			}else{
				$("#pi-"+shortcode+"-sc .form-control").each(function()
				{
					_getSettings += $(this).attr("name") + '="' + $(this).val() + '" ';
				})

				if ( _getSettings !='' )
				{
					_getSettings = '[pi_wiloke_'+shortcode+" " + _getSettings.trim()+']';
				}else{
					_getSettings = '[pi_wiloke_'+shortcode+']';
				}
			}
			/* get the TinyMCE version to account for API diffs */
			var tmce_ver = window.tinyMCE.majorVersion;

			if (tmce_ver >= 4)
			{
		 		window.tinyMCE.execCommand('mceInsertContent', false, _getSettings);
			}else{
		 		window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false, _getSettings);
			}
			_getSettings = "";

			

			pi_clear_something();

			tb_remove();

			return false;
		})

		$("#TB_closeWindowButton").click(function() 
		{
			pi_clear_something();
			return false;
		});


		function pi_clear_something()
		{
			$("#pi-insert-shortcode").unbind('click');
			document.getElementById("pi-reset").reset();
			$("#pi-reset").find(".is_clone").remove();
			$(".pi-addtabs").unbind("click");
			$(".pi-addaccordion").unbind("click");
		}

		switch ( shortcode )
		{
			case 'divider':
				piDivider();
				break;
			case 'progress':
				piPreviewProgressBar();
				break;
			case 'button':
				piPreviewButton();
				break;
			case 'quote':
				piPreviewQuote();
				break;
			case 'alert':
				piPreviewAlert();
				break;
			case 'panel':
				piPreviewPanel();
				break;
			case 'tabs':
				piAddTabs();
				break;
			case 'accordion':
				piAddAccordion();
				break;
		}

		/*Divider*/
		function piDivider()
		{
			$(".pi-divider").change(function()
			{
				var _style = $(this).val(), $target = $("#pi-divider-sc .sepIcon");
				$target.attr("class", "sepIcon "+_style);
			})
		}

		/*Tabs*/
		function piAddTabs()
		{
			$(".wrap-setting").fadeIn();
			$(".pi-addtabs").click(function()
			{
				var _clone 		= "",
					$statHere   = $(this).parent();
					$(".wrap-setting").fadeOut();
					_clone 		= $statHere.prev().clone();
					_clone.find("[name='title']").val("Tab title");
					_clone.find("[name='content']").text("Tab content");
					_clone.find(".wrap-setting").fadeIn();
					_clone.addClass("is_clone");
					$statHere.before(_clone);

				return false;
			})

			$("#pi-tabs-sc").on("click", ".pi-removetab", function(event)
			{
				event.preventDefault();
				if ( $(this).closest(".pi-shortcode-settings").find(".pi-item").length > 1 )
				{
					$(this).closest(".pi-item").remove();
				}else{
					alert("Oop, You need at least one item");
				}
			})
		}

		/*Accordion*/
		function piAddAccordion()
		{
			$(".wrap-setting").fadeIn();
			$(".pi-addaccordion").click(function()
			{
				var _clone 		= "",
					$statHere   = $(this).parent();
					_clone 		= $statHere.prev().clone();
					_clone.find("[name='title']").val("Title");
					_clone.find("[name='content']").text("Content");
					_clone.addClass("is_clone");
					
					$statHere.before(_clone);
				return false;
			})

			$("#pi-accordion-sc").on("click", ".pi-removeitem", function(event)
			{
				event.preventDefault();
				if ( $(this).closest(".pi-shortcode-settings").find(".pi-item").length > 1 )
				{
					$(this).closest(".pi-item").remove();
				}else{
					alert("Oop, You need at least one item");
				}
			})
		}

		/*Progress bar*/
		function piPreviewProgressBar()
		{
			var $progressBar = $("#pi-progress-sc .pi-preview .progress-bar");
			$("#pi-progress-sc [name='percent']").change(function()
			{
				$progressBar.css({width: $(this).val() + "%"});
			});

			$("#pi-progress-sc [name='active']").change(function()
			{
				$progressBar.toggleClass("active");
			});

			$("#pi-progress-sc [name='striped']").change(function()
			{
				$progressBar.toggleClass("progress-bar-striped");
			});

			$("#pi-progress-sc [name='contextual']").change(function()
			{
				$progressBar.removeClass("progress-bar-success progress-bar-danger progress-bar-info progress-bar-warning");
				$progressBar.addClass("progress-bar-"+$(this).val());
			});
		}

		/*Button*/
		function piPreviewButton()
		{
			var $button = $("#pi-button-sc .pi-preview .btn");

			$("#pi-button-sc [name='button_name']").change(function()
			{
				$button.html($(this).val());
			});

			$("#pi-button-sc [name='contextual']").change(function()
			{
				$button.removeClass("h-btn btn-success btn-danger btn-info btn-warning");
				$button.addClass($(this).val());
			});	

			$("#pi-button-sc [name='size']").change(function()
			{
				$button.removeClass("btn-sm btn-lg btn-default");
				$button.addClass($(this).val());
			});	

			$("#pi-button-sc [name='size']").change(function()
			{
				$button.removeClass("btn-default btn-small btn-lg");
				$button.addClass($(this).val());
			});	
		}

		/*Quote*/
		function piPreviewQuote()
		{
			var $quote = $("#pi-quote-sc .pi-preview blockquote");

			$("#pi-quote-sc [name='quote']").keyup(function()
			{
				$quote.find("p").html($(this).val());
			});

			$("#pi-quote-sc [name='author']").keyup(function()
			{
				$quote.find("cite").html($(this).val());
			});	
		}

		/*Alert*/
		function piPreviewAlert()
		{
			var $alert = $("#pi-alert-sc .pi-preview .alert");

			$("#pi-alert-sc [name='alert']").keyup(function()
			{
				$alert.html($(this).val());
			});

			$("#pi-alert-sc [name='contextual']").change(function()
			{
				$alert.removeClass("alert-success alert-danger alert-info alert-warning");
				$alert.addClass($(this).val());
			});	
		}
	
		/*Panel*/
		function piPreviewPanel()
		{
			var $panel = $("#pi-panel-sc .pi-preview .panel");

			$("#pi-panel-sc [name='title']").keyup(function()
			{
				$panel.find(".panel-title").html($(this).val());
			});

			$("#pi-panel-sc [name='content']").keyup(function()
			{
				$panel.find(".panel-body").html($(this).val());
			});	

			$("#pi-panel-sc [name='contextual']").change(function()
			{
				$panel.removeClass("panel-primary panel-success panel-danger panel-info panel-warning");
				$panel.addClass($(this).val());
			});	
		}

	}
	
	$(document).ready(function()
	{
		var $doc = $(document);
		/*Toggle Slide*/
		$doc.on("click", ".pi-item-toggle .dashicons", function(){
			$(this).next().toggle();
		})
	})

})(jQuery, window, document)
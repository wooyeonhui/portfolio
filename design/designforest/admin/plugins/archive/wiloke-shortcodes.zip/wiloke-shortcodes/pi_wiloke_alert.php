<?php 
$atts = shortcode_atts(
	array( 
		'alert' 			=> 'This is danger alert!',
		'contextual'	  	=> 'alert-danger'
	),
	$atts
);

$output .= '<div class="alert '.esc_attr($atts['contextual']).'" role="alert">'.wp_unslash($atts['alert']).'</div>';

return $output;
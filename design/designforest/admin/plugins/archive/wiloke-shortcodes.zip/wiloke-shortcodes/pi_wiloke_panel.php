<?php 
$atts = shortcode_atts(
	array(
		'title' 	 => 'Panel title',
		'content'	 => 'Panel content',
		'contextual' => 'panel-success'
	),
	$atts
);


$output .= '<div class="panel '.esc_attr($atts['contextual']).'">';
if ( !empty($atts['title']) ) :
$output .= '<div class="panel-heading">'.wp_unslash($atts['title']).'</div>';
endif;

$output .= '<div class="panel-body">';
$output .= wp_unslash($atts['content']);
$output .= '</div>';

$output .= '</div>';

return $output;
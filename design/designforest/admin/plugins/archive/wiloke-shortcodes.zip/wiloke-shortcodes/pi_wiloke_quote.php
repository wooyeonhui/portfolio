<?php 
$atts = shortcode_atts(
	array(
		'quote' 	=> 'Stay hungry Stay Foolish',
		'author'	=> 'Steve Jobs',
	),
	$atts
);

$output .= '<blockquote class="quote">';
	$output .= '<p>' . wp_unslash($atts['quote']) . '</p>';
	$output .= '<cite>' . wp_unslash($atts['author']) . '</cite>';
$output .= '</blockquote>';

return $output;
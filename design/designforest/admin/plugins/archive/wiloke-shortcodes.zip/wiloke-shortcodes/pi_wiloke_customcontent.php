<?php 
$atts = shortcode_atts(
	array(
		'image' 	 	=> '',
		'title'	 	 	=> 'Thumbnail label',
		'content' 	 	=> 'Custom content',
		'button_name'	=> 'Button',
		'link'			=> ''
	),
	$atts
);


$output .='<div class="thumbnail">';
  if ( !empty($atts['image']) ) :
  $output .='<img src="'.esc_url($atts['image']).'" alt="'.get_option('blogname').'">';
  endif;
  $output .='<div class="caption">';
    $output .='<h3>'.wp_unslash($atts['title']).'</h3>';
    $output .='<p>'.wp_unslash($atts['content']).'</p>';
    if ( !empty($atts['link']) ) :
    $output .='<p><a href="'.esc_url($atts['link']).'" class="btn btn-primary" role="button">'.wp_unslash($atts['button_name']).'</a></p>';
	endif;
  $output .='</div>';
$output .='</div>';

return $output;